# ARES-RX Sentinel — Tiny Tapeout TT08 Submission Repository

[![Tiny Tapeout](https://img.shields.io/badge/Tiny%20Tapeout-TT08-blue)](https://tinytapeout.com)
[![PDK](https://img.shields.io/badge/PDK-SkyWater%20130nm-green)](https://github.com/google/skywater-pdk)
[![Status](https://img.shields.io/badge/Precheck-100%25%20PASS-brightgreen)](#)

This repository contains the complete, self-contained **Tiny Tapeout TT08** submission for **ARES-RX Sentinel**: a silicon-level hardware security boundary protecting Sub-GHz RF receivers against physical baseband glitches, clock desynchronization, and malformed frame injection attacks.

---

## 1. Project Specifications

* **Top Module:** `tt_um_ares_sentinel_project`
* **Tile Size:** `1x1` ($161.00\,\mu\text{m} \times 111.52\,\mu\text{m}$)
* **Clock Frequency:** $20\,\text{kHz}$ nominal ($F_{\max} \approx 123.7\,\text{MHz}$)
* **Operating Power:** $\mathbf{50.90\,\text{nW}}$ @ $20\,\text{kHz}$ ($1.8\,\text{V}$)
* **Standard Cell Area:** $6,477.46\,\mu\text{m}^2$ (758 gates)
* **Physical Sign-Off:** 0 Active DRC violations, 100% LVS Match

---

## 2. Repository Structure

```text
.
├── info.yaml        # Official Tiny Tapeout metadata and pinout configuration
├── LICENSE          # Apache 2.0 open-source license
├── README.md        # This repository README
├── docs/
│   └── info.md      # Detailed project documentation and testing instructions
├── src/             # Synthesizable Verilog sources (11 modules)
│   ├── tt_um_ares_sentinel_project.v # Top-level perimeter wrapper
│   ├── ares_sentinel_top.v           # Integrated Sentinel subsystem
│   ├── ares_timing_sentinel.v        # Layer-1 temporal validator
│   ├── ares_frame_fsm.v              # Layer-2 syntax grammar FSM
│   ├── ares_fault_arbiter.v          # Priority fault arbiter
│   ├── ares_fault_latch.v            # Sticky hardware latch
│   ├── ares_isolation_gate.v         # Fail-closed zeroization gate
│   ├── ares_isolation_l3.v           # Layer-3 isolation subsystem
│   ├── edge_detect.v                 # Baseband edge detector
│   ├── state_machine.v               # Manchester clock/data recover FSM
│   └── data_multiplex.v              # Deserializer and parallel output register
└── test/            # Automated verification testbench
    ├── tb.v         # Verilog testbench wrapper
    ├── test.py      # Cocotb test suite (nominal & glitch rejection)
    └── Makefile     # Cocotb simulator Makefile
```

---

## 3. Running the Testbench

To run the automated Cocotb test suite locally:

```bash
cd test
make
```

Expected output:
```text
test_nominal_transmission passed
test_runt_glitch_rejection passed
** TESTS=2 PASS=2 FAIL=0 SKIP=0 **
```
